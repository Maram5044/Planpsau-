
// --- Utilities ---
const DAYS = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس"];
const DAY_KEYS = ["sun","mon","tue","wed","thu"];

// time helpers
function timeToMinutes(t){ // "08:00" -> 480
  const [h,m] = t.split(":").map(Number);
  return h*60 + m;
}
function overlaps(a,b){
  // segments: {start,end, day}
  return a.day===b.day && Math.max(a.start,b.start) < Math.min(a.end,b.end);
}
function gapOK(daySlots,noBreaks){
  if(!noBreaks) return true;
  // ensure no gaps larger than 45 minutes between consecutive slots in same day
  const arr = [...daySlots].sort((x,y)=>x.start-y.start);
  for(let i=1;i<arr.length;i++){
    const gap = arr[i].start - arr[i-1].end;
    if(gap > 45) return false;
  }
  return true;
}

// --- State ---
let DATA = null;
let currentCombos = [];
let currentIndex = 0;

// --- DOM ---
const genderSel = document.getElementById('gender');
const collegeSel = document.getElementById('college');
const majorSel = document.getElementById('major');
const coursesBox = document.getElementById('courses');
const btnGenerate = document.getElementById('btn-generate');
const btnReset = document.getElementById('btn-reset');
const scheduleWrapper = document.getElementById('schedule-wrapper');
const counterEl = document.getElementById('counter');

// load data
fetch('data.json').then(r=>r.json()).then(json=>{
  DATA = json;
  populateColleges();
});

function populateColleges(){
  collegeSel.innerHTML = "";
  Object.keys(DATA.colleges).forEach(key=>{
    const opt = document.createElement('option');
    opt.value = key; opt.textContent = DATA.colleges[key].name;
    collegeSel.appendChild(opt);
  });
  populateMajors();
}
collegeSel.addEventListener('change', populateMajors);
genderSel.addEventListener('change', renderCourses);

function populateMajors(){
  const c = DATA.colleges[collegeSel.value];
  majorSel.innerHTML = "";
  Object.keys(c.majors).forEach(key=>{
    const opt = document.createElement('option');
    opt.value = key; opt.textContent = c.majors[key].name;
    majorSel.appendChild(opt);
  });
  renderCourses();
}
majorSel.addEventListener('change', renderCourses);

function renderCourses(){
  const c = DATA.colleges[collegeSel.value];
  const m = c.majors[majorSel.value];
  const gender = genderSel.value;
  coursesBox.innerHTML = "";
  (m?.courses||[]).forEach(course=>{
    const hasAny = course.sections.some(s=>!s.gender || s.gender===gender);
    if(!hasAny) return;
    const el = document.createElement('label');
    el.className = 'course-item';
    el.innerHTML = `<span>${course.code} — ${course.name}</span>
    <input type="checkbox" data-code="${course.code}" />`;
    coursesBox.appendChild(el);
  });
}

function getSelectedCourses(){
  const selectedCodes = Array.from(coursesBox.querySelectorAll('input[type=checkbox]:checked'))
    .map(i=>i.dataset.code);
  const c = DATA.colleges[collegeSel.value];
  const m = c.majors[majorSel.value];
  return (m?.courses||[]).filter(x=>selectedCodes.includes(x.code));
}

// generate schedules (combinations) with constraints
btnGenerate.addEventListener('click', ()=>{
  const offDays = {
    sun: document.getElementById('off-sun').checked,
    mon: document.getElementById('off-mon').checked,
    tue: document.getElementById('off-tue').checked,
    wed: document.getElementById('off-wed').checked,
    thu: document.getElementById('off-thu').checked,
  };
  const openOnly = document.getElementById('open-only').checked;
  const noBreaks = document.getElementById('no-breaks').checked;
  const gender = genderSel.value;

  const courses = getSelectedCourses();
  if(courses.length===0) { alert("اختر موادك أولاً"); return; }

  // Prepare sections per course
  const sectionsPerCourse = courses.map(course=>{
    const secs = course.sections.filter(s=>
      (!s.gender || s.gender===gender) &&
      (!openOnly || s.open)
    );
    return secs.map(s=>({course, section:s}));
  });

  // backtracking
  currentCombos = [];
  const partial = [];
  function backtrack(i){
    if(i===sectionsPerCourse.length){
      // Validate offDays + noBreaks constraints
      const daySlots = {sun:[],mon:[],tue:[],wed:[],thu:[]};
      for(const item of partial){
        for(const mtg of item.section.meetings){
          const slot = {
            day: mtg.day,
            start: timeToMinutes(mtg.start),
            end: timeToMinutes(mtg.end),
            meta: { course: item.course, section: item.section, mtg }
          };
          daySlots[mtg.day].push(slot);
        }
      }
      // offDays check
      for(const k of Object.keys(offDays)){
        if(offDays[k] && daySlots[k].length>0) return;
      }
      // overlaps check
      const allSlots = Object.values(daySlots).flat();
      for(let a=0;a<allSlots.length;a++){
        for(let b=a+1;b<allSlots.length;b++){
          if(overlaps(allSlots[a], allSlots[b])) return;
        }
      }
      // noBreaks per day
      for(const k of Object.keys(daySlots)){
        if(!gapOK(daySlots[k], noBreaks)) return;
      }

      currentCombos.push(JSON.parse(JSON.stringify(partial)));
      return;
    }
    for(const sec of sectionsPerCourse[i]){
      partial.push(sec);
      backtrack(i+1);
      partial.pop();
    }
  }
  backtrack(0);
  currentIndex = 0;
  renderCurrent();
});

btnReset.addEventListener('click', ()=>{
  coursesBox.querySelectorAll("input[type=checkbox]").forEach(i=> i.checked=false);
  currentCombos = [];
  scheduleWrapper.innerHTML = '<div class="placeholder">انشئ جدول للبدء</div>';
  counterEl.textContent = "0 / 00";
});

document.getElementById('prev').addEventListener('click', ()=>{
  if(currentCombos.length===0) return;
  currentIndex = (currentIndex-1+currentCombos.length)%currentCombos.length;
  renderCurrent();
});
document.getElementById('next').addEventListener('click', ()=>{
  if(currentCombos.length===0) return;
  currentIndex = (currentIndex+1)%currentCombos.length;
  renderCurrent();
});

function renderCurrent(){
  if(currentCombos.length===0){
    scheduleWrapper.innerHTML = '<div class="placeholder">لا توجد نتائج — غيّر المرشّحات أو عدد المواد</div>';
    counterEl.textContent = "0 / 00";
    return;
  }
  const data = currentCombos[currentIndex];
  counterEl.textContent = (currentIndex+1) + " / " + String(currentCombos.length).padStart(2,'0');
  scheduleWrapper.innerHTML = buildTableHTML(data, document.getElementById('show-details').checked);
}

document.getElementById('show-details').addEventListener('change', ()=> renderCurrent());

function buildTableHTML(combo, showDetails){
  // grid: time rows (08:00 .. 18:00 step 2h)
  const times = [
    ["08:00","10:00"], ["10:00","12:00"], ["12:00","14:00"], ["14:00","16:00"], ["16:00","18:00"]
  ];
  const grid = {};
  DAY_KEYS.forEach(d=> grid[d]=times.map(()=>[]));

  combo.forEach(item=>{
    item.section.meetings.forEach(m=>{
      const row = times.findIndex(t=> t[0]===m.start && t[1]===m.end);
      if(row>=0){
        grid[m.day][row].push({
          code: item.course.code,
          name: item.course.name,
          room: m.room, instr: item.section.instructor,
          sec: item.section.id
        });
      }
    });
  });

  let html = `<table class="schedule"><thead><tr>
    <th class="time-col">الوقت \\ اليوم</th>`;
  DAYS.forEach(d=> html += `<th>${d}</th>`);
  html += `</tr></thead><tbody>`;

  times.forEach((t,ri)=>{
    html += `<tr><th class="time-col">${t[0]} - ${t[1]}</th>`;
    DAY_KEYS.forEach((dk)=>{
      const cell = grid[dk][ri];
      if(cell.length===0){ html += `<td class="slot"></td>`; }
      else{
        const badges = cell.map(c=> `<div class="badge">
          <span class="name">${c.code}</span>
          <span class="meta">${c.name}${showDetails ? ` — ${c.room} — ${c.instr} (${c.sec})` : ""}</span>
        </div>`).join("");
        html += `<td class="slot">${badges}</td>`;
      }
    });
    html += `</tr>`;
  });
  html += `</tbody></table>`;
  return html;
}

// Export as image
document.getElementById('btn-save-image').addEventListener('click', async ()=>{
  const node = document.querySelector('.carousel');
  const canvas = await html2canvas(node, {scale:2});
  const link = document.createElement('a');
  link.download = 'جدولي.png';
  link.href = canvas.toDataURL('image/png');
  link.click();
});

// Export as PDF
document.getElementById('btn-save-pdf').addEventListener('click', async ()=>{
  const node = document.querySelector('.carousel');
  const canvas = await html2canvas(node, {scale:2});
  const imgData = canvas.toDataURL('image/png');
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF('l','pt','a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  // Fit image
  const ratio = Math.min(pageWidth/canvas.width, pageHeight/canvas.height);
  const imgW = canvas.width*ratio, imgH = canvas.height*ratio;
  const x = (pageWidth - imgW)/2, y = (pageHeight - imgH)/2;
  pdf.addImage(imgData, 'PNG', x, y, imgW, imgH);
  pdf.save('جدولي.pdf');
});
